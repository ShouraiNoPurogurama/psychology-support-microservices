﻿namespace Image.API
{
    public interface IAssemblyMarker
    {
    }
}
