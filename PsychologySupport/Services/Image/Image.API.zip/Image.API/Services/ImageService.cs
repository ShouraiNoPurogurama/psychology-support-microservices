﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Image.API.Data.Common;
using Image.API.ServiceContracts;

namespace Image.API.Services
{
    public class ImageService : IImageService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName;

        public ImageService(IConfiguration configuration)
        {
            _blobServiceClient = new BlobServiceClient(configuration["AzureBlobStorage:ConnectionString"]);
            _containerName = configuration["AzureBlobStorage:ContainerName"];
        }

        public async Task<string> UploadImageAsync(IFormFile file, OwnerType ownerType, Guid ownerId)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("Invalid file.");

            var extension = Path.GetExtension(file.FileName);
            var blobName = $"{ownerType}/{ownerId}/{Guid.NewGuid()}{extension}";
            var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

            var blobClient = containerClient.GetBlobClient(blobName);
            await using var stream = file.OpenReadStream();
            await blobClient.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });

            return blobClient.Uri.ToString();
        }
    }
}
