﻿using Image.API.Data.Common;
using Image.API.ServiceContracts;
using Microsoft.AspNetCore.Mvc;

namespace Image.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        private readonly IImageService _imageService;

        public ImageController(IImageService imageService)
        {
            _imageService = imageService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadImage([FromForm] IFormFile file, [FromQuery] OwnerType ownerType, [FromQuery] Guid ownerId)
        {
            try
            {
                var imageUrl = await _imageService.UploadImageAsync(file, ownerType, ownerId);
                return Ok(new { Url = imageUrl });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Error = ex.Message });
            }
        }
    }
}
