﻿namespace Auth.API;

public interface IAssemblyMarker
{
}